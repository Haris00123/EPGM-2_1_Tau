# epgm_model/__init__.py

from .EPGM import EPGM

#Assiginiing the EPGM class to __all__ for module export
__all__ = ['EPGM']
